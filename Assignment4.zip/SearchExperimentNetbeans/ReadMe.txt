Here is how to run:
java -jar "F:\SearchExperimentNetbeans\dist\SearchExperimentNetbeans.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
******************************************************************************